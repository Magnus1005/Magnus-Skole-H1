﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestXUnit
{
    public class TESTERPRO
    {
        [Fact]
        public static void TESTER()
        {
            // Arrage
            // Her skrives indput data og hvad outputet skal være

            // Act
            // Her køres metoden

            // Assert
            Assert.Equal(1, 1);
            
        }
    }
}
